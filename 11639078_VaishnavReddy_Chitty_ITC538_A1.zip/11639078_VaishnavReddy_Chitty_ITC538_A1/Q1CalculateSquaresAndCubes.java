/** The below program is used to calculate the squares and cubes of the given number ranges which will be prompted on run 
 * 
 * @author ChittyVaishnav
 *
 */
import java.util.Scanner;// importing the Scanner class
public class Q1CalculateSquaresAndCubes {
// the execution of the program starts from this main method
	public static void main(String[] args) {
		//Creating a Scanner object 
		  Scanner scanNumber = new Scanner(System.in);
			int firstNumber,secondNumber,difference;// declaring variables for input 
			System.out.println("\"Welcome to Calculator program!\"");
			System.out.println("The program calculates the square's and cube's of the given number range");
			System.out.println("Please enter the 1st number");
			firstNumber = scanNumber.nextInt();// reads the 1st number
			System.out.println("Please enter the 2nd number");
			secondNumber = scanNumber.nextInt();//reads the second number
			difference = secondNumber-firstNumber;//calculating the difference for getting the max increment
			System.out.println("Number\t\t"+"Square\t\t"+"Cube");
			for(int i=0;i<=difference;i++)// the loop iterates till we get to the max value
			{
			System.out.println(firstNumber + "\t\t"+(firstNumber*firstNumber)+"\t\t"+(firstNumber*firstNumber*firstNumber));
			firstNumber++;// for increment of the number
			}
			System.out.println("\"Goodbye, thank you for using our program!\"");
			scanNumber.close();
	}

}