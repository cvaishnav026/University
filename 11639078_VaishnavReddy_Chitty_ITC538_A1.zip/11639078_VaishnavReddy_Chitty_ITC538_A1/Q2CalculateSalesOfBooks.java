/**
 * The below program is used to calculate  the total charge corresponding to purchase of books at a fictional annual book festival. 
 * The price of each book is based on its category as described below: 
Large print hardback books $10 each or three for $20
Small print hardback books $7 each or two for $10
All softcover books $5 each or five for $15
 * @author ChittyVaishnav
 * 
 */

import java.util.Scanner;//The util package is imported for Scanner class
public class Q2CalculateSalesOfBooks {

	public static void main(String[] args) {//main method starts from here
		
		Scanner readNumber = new Scanner(System.in);//The scanner object is defined to read numbers in the program
		Scanner readCharacter= new Scanner(System.in);//The scanner object is defined to read character  in the program
		int currentBill=0;// the variable is used to calculate the current bill for 
		int totalSales=0;// the variable is used to calculate the total sales 
		String check="y";// the variable can be used to check the continuation of the request t o user
System.out.println("Welcome to the annual book festival!");
while(true)// The while loop will continue infinitely 
{
	System.out.println();
System.out.print("Enter the number of large print hardback books purchased:");
int numberOfLargePrintHardbackBooks = readNumber.nextInt();//here we read the number of large print hardback from user
int quotient1 = numberOfLargePrintHardbackBooks/3;// the quotient here is calculated in bases of 3 as question stated  we calculate for multiples of 3
int remainder1 = numberOfLargePrintHardbackBooks%3;// the remainder is used to calculate for remaining books which are not in the multiple of 3
System.out.print("Enter the number of small print hardback books purchased:");
int numberOfSmallPrintHardbackBooks = readNumber.nextInt();//we are reading the number of small print hardback
int quotient2 = numberOfSmallPrintHardbackBooks/2;// the quotient here is calculated in bases of 2 as question stated  we calculate for multiples of 2
int remainder2 = numberOfSmallPrintHardbackBooks%2;// the remainder is used to calculate for remaining books which are not in the multiple of 2
System.out.print("Enter the number of softcover books purchased:");
int numberOfSoftcoverBooks = readNumber.nextInt();// we are reading number of softcover books purchased
int quotient3 = numberOfSoftcoverBooks/5;// the quotient here is calculated in bases of 5 as question stated  we calculate for multiples of 5
int remainder3 = numberOfSoftcoverBooks%5;// the remainder is used to calculate for remaining books which are not in the multiple of 5

currentBill = ((quotient1*20)+(remainder1*10))+((quotient2*10)+(remainder2*7))+((quotient3*15)+(remainder3*5));// The current bill is calculated by using the quotient and remainder  based on simple mathematical calculation
totalSales += currentBill;// here we calculate the total bill or sales 
System.out.print("Total bill is:$"+currentBill);// outputs the bill for current instance
System.out.println();
System.out.print("\nWould you like to calculate another bill (y/n)?");
check=readCharacter.next();// will read the string entered by the user

if(check.equals("n")) {// if the entered string value is equal to 'n' then the infinite loop breaks 
	break;
}
else {continue;}//any other character will continue the loop
}
System.out.println();
System.out.print("Total sales in this session:$"+totalSales);// prints the total no of sales after the loop is ended
System.out.println();
System.out.print("Goodbye!");
readNumber.close();// closing the scanner object
readCharacter.close();//closing the scanner object
	}

}
