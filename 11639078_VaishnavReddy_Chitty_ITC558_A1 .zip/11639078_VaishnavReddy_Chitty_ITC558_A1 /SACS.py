#The program is called Shape Area Circulation System which is used to
#calculate areas of 6 candidate shapes:
#Triangle,Rectangle,trapezoid,Circle,Ellipse, and Parallellogram
print("------------------------------------------------")
print("Welcome to Shape Area Calculation System (SACS)")
print("------------------------------------------------")
print("1. Triangle 2. Rectangle 3. Trapezoid")
print("4. Circle   5. Ellipse   6. Parallelogram")
#inputing the user option for the type of shape
option=int(input("Please select the shape you would like to calculate the \
area for (1-6):"))
print()
print("Thank you!")
#The math function is being imported for inbuilt constants
import math
#Constants are always in Capitals
PI=math.pi
#if user selects option 1 then the program goes inside 
if(option==1):
    print("The shape you selected is: Triangle")
    #user enters the base and height of a triangle
    base=float(input("Please input the base(in centimeter)"))
    height=float(input("Please input the height(in centimeter)"))
    #Area of traignle is calculated
    triangleArea=(0.5)*base*height
    #It will be printed upto 2 decimals with format function
    print("The area of the triangle is",format(triangleArea,'.2f'),"\
square centimeters.")
    #if user selects option 2 then the program goes inside 
elif(option==2):
    print("The shape you selected is: Rectangle")
     #user enters the length and width of a rectangle
    length=float(input("Please input the length(in centimeter)"))
    width=float(input("Please input the width(in centimeter)"))
      #Area of rectangle is calculated
    rectangleArea=length*width
    print("The area of the rectangleis",format(rectangleArea,'.2f'),"\
square centimeters.")
    #if user selects option 3 then the program goes inside 
elif(option==3):
    print("The shape you selected is: Trapezoid")
    #user enters the parallel sides of a Trapezoid
    smallParallelSide=float(input("Please input the smaller \
parallel side(in centimeter)"))
    largeParallelSide=float(input("Please input the larger parallel \
side(in centimeter)"))
    height=float(input("Please input the height(in centimeter)"))
     #Area of Trapezoid is calculated
    trapezoidArea=(0.5)*(smallParallelSide+largeParallelSide)*height
    print("The area of the trapezoid is",format(trapezoidArea,'.2f'),"\
square centimeters.")
    #if user selects option 4 then the program goes inside 
elif(option==4):
    print("The shape you selected is: Circle")
    #user enters the radius
    radius=float(input("Please input the radius(in centimeter)"))
     #Area of circle is calculated
    circleArea=PI*radius*radius
    print("The area of the circle is",format(circleArea,'.2f'),"\
square centimeters.")
    #if user selects option 5 then the program goes inside 
elif(option==5):
    print("The shape you selected is: Ellipse")
    #user enters the short and long axises present in an ellipse
    shorterAxis=float(input("Please input the shoter axis(in centimeter)"))
    longerAxis=float(input("Please input the longer axis(in centimeter)"))
     #Area of rectangle is calculated
    ellipseArea=PI*shorterAxis*longerAxis
    print("The area of the ellipse is",format(ellipseArea,'.2f'),"\
square centimeters.")
    #if user selects option 6 then the program goes inside 
elif(option==6):
    print("The shape you selected is: Parallelogram")
    #user enters the base and height of a parlellogram
    base=float(input("Please input the base(in centimeter)"))
    height=float(input("Please input the height(in centimeter)"))
     #Area of rectangle is calculated
    parallelogramArea=base*height
    print("The area of the parallelogram is",format(parallelogramArea,'.2f'),"\
square centimeters.")
    #if user selects other than (1-6) then the program goes inside 
else:
    print("The selected option is not available")
print()
print("Thanks for using Shape Area Calculation System!")
print("Goodbye!")

    
